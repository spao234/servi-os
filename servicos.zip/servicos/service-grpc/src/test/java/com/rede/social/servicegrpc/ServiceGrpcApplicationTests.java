package com.rede.social.servicegrpc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceGrpcApplicationTests {

    @Test
    void contextLoads() {
    }

}
