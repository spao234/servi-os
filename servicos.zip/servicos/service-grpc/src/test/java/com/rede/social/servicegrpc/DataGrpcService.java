@GrpcService
public class DataGrpcService extends DataServiceGrpc.DataServiceImplBase {

    @Autowired
    private DataService dataService;

    @Override
    public void getData(DataRequest request, StreamObserver<DataResponse> responseObserver) {
        Data data = dataService.getById(request.getId());
        DataResponse response = DataResponse.newBuilder()
                .setId(data.getId())
                .setName(data.getName())
                .setDescription(data.getDescription())
                .build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }
}
