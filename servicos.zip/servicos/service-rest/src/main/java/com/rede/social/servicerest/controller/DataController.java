package com.rede.social.service.rest.controller;

import com.rede.social.service.rest.model.Data;
import com.rede.social.service.rest.service.DataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/data")
public class DataController {

    @Autowired
    private DataService dataService;

    @PostMapping
    public ResponseEntity<Data> createData(@RequestBody Data data) {
        return ResponseEntity.ok(dataService.save(data));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Data> getData(@PathVariable String id) {
        return ResponseEntity.ok(dataService.getById(id));
    }
}
