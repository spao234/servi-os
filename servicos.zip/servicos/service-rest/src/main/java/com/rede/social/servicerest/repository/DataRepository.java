package com.rede.social.service.rest.repository;

import com.rede.social.service.rest.model.Data;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DataRepository extends MongoRepository<Data, String> {}
