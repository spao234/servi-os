package com.rede.social.servicerest1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceRest1Application {

    public static void main(String[] args) {
        SpringApplication.run(ServiceRest1Application.class, args);
    }

}
