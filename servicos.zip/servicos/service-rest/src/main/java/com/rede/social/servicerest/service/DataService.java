package com.rede.social.service.rest.service;

import com.rede.social.service.rest.model.Data;
import com.rede.social.service.rest.repository.DataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DataService {

    @Autowired
    private DataRepository repository;

    public Data save(Data data) {
        return repository.save(data);
    }

    public Data getById(String id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Data not found"));
    }
}
