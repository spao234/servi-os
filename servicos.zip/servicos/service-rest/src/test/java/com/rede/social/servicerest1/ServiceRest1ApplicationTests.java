package com.rede.social.servicerest1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRest1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
