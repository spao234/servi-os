package com.rede.social.serviceclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
