public DataResponse getDataFromGrpc(String id) {
    ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 9090).usePlaintext().build();
    DataServiceGrpc.DataServiceBlockingStub stub = DataServiceGrpc.newBlockingStub(channel);

    DataRequest request = DataRequest.newBuilder().setId(id).build();
    return stub.getData(request);
}
