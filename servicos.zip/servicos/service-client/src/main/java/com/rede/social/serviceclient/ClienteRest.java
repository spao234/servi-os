public Data getDataFromRest(String id) {
    RestTemplate restTemplate = new RestTemplate();
    return restTemplate.getForObject("http://localhost:8080/api/v1/data/" + id, Data.class);
}
